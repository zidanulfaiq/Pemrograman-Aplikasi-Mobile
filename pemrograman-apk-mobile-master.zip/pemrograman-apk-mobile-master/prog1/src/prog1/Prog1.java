/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog1;

/**
 *
 * @author Lenovo
 */
public class Prog1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         int jumlah = 5;
        for (int z=0;z<jumlah;z++){
            for (int y=0;y<=z;y++){
                System.out.print("X");
            }System.out.println();
        }
    }
    
}
